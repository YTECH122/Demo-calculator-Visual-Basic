﻿Public Class Form1

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim a, b As Integer
        Dim sum As Integer
        a = TextBox1.Text
        b = TextBox2.Text
        sum = a + b
        If RadioButton1.Checked = True Then
            sum = a + b
            Label3.Text = sum
        ElseIf RadioButton2.Checked = True Then
            sum = a - b
            Label3.Text = sum
        ElseIf RadioButton3.Checked = True Then
            sum = a * b
            Label3.Text = sum
        ElseIf RadioButton4.Checked = True Then
            sum = a / b
            Label3.Text = sum

            a = TextBox1.Text
            b = TextBox2.Text
            sum = a + b
        End If
    End Sub

    Private Sub Label6_Click(sender As Object, e As EventArgs) Handles Label6.Click

    End Sub
End Class
